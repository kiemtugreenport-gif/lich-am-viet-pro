package vn.lichamviet

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Today
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDate
import java.time.YearMonth

private val Green = Color(0xFF26745B)
private val Cream = Color(0xFFF7F5EE)
private val Gold = Color(0xFFC18B3B)
private val Ink = Color(0xFF18352D)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { LichAmProApp() }
    }
}

@Composable
fun LichAmProApp() {
    var month by remember { mutableStateOf(YearMonth.now()) }
    var selected by remember { mutableStateOf(LocalDate.now()) }
    var dark by remember { mutableStateOf(false) }
    var accent by remember { mutableStateOf(0) }
    val today = LocalDate.now()
    val primary = listOf(Green, Color(0xFF8A3D35), Color(0xFF315D91))[accent]
    val bg = if (dark) Color(0xFF101B18) else Cream
    val card = if (dark) Color(0xFF1C2B26) else Color.White
    val ink = if (dark) Color(0xFFF2F4EF) else Ink
    val muted = if (dark) Color(0xFFB7C5BE) else Color.Gray
    val days = remember(month) {
        val first = month.atDay(1)
        val offset = first.dayOfWeek.value % 7
        List(offset) { null } + (1..month.lengthOfMonth()).map { month.atDay(it) }
    }
    MaterialTheme(colorScheme = if (dark) darkColorScheme(primary=primary, background=bg, surface=card)
        else lightColorScheme(primary=primary, background=bg, surface=card)) {
        Surface(Modifier.fillMaxSize(), color=bg) {
            Column(Modifier.fillMaxSize().safeDrawingPadding().padding(horizontal=16.dp, vertical=12.dp)) {
                Row(verticalAlignment=Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("LỊCH ÂM VIỆT PRO", color=primary, fontSize=12.sp, fontWeight=FontWeight.Bold, letterSpacing=2.sp)
                        Text("Lịch vạn niên", color=ink, fontSize=27.sp, fontWeight=FontWeight.Bold)
                    }
                    IconButton(onClick={ month=YearMonth.from(today); selected=today }) {
                        Icon(Icons.Default.Today, contentDescription="Hôm nay", tint=primary)
                    }
                }
                Spacer(Modifier.height(12.dp))
                Card(shape=RoundedCornerShape(22.dp), colors=CardDefaults.cardColors(containerColor=card)) {
                    Column(Modifier.padding(12.dp)) {
                        Row(verticalAlignment=Alignment.CenterVertically) {
                            IconButton(onClick={month=month.minusMonths(1)}) { Icon(Icons.Default.ChevronLeft, null, tint=ink) }
                            Text("${month.monthValue} / ${month.year}", Modifier.weight(1f), textAlign=TextAlign.Center,
                                color=ink, fontSize=19.sp, fontWeight=FontWeight.Bold)
                            IconButton(onClick={month=month.plusMonths(1)}) { Icon(Icons.Default.ChevronRight, null, tint=ink) }
                        }
                        Row(Modifier.fillMaxWidth()) {
                            listOf("CN","T2","T3","T4","T5","T6","T7").forEachIndexed { i,s ->
                                Text(s, Modifier.weight(1f).padding(vertical=7.dp), textAlign=TextAlign.Center,
                                    color=if(i==0) Color(0xFFD36B5B) else muted, fontSize=11.sp, fontWeight=FontWeight.Bold)
                            }
                        }
                        LazyVerticalGrid(columns=GridCells.Fixed(7), modifier=Modifier.fillMaxWidth().heightIn(max=360.dp),
                            userScrollEnabled=false) {
                            items(days) { date ->
                                if (date==null) Box(Modifier.aspectRatio(.85f))
                                else {
                                    val lunar = remember(date) { VietnameseLunar.toLunar(date) }
                                    val chosen = date==selected
                                    val isToday = date==today
                                    Column(Modifier.padding(2.dp).clip(RoundedCornerShape(10.dp))
                                        .background(if(chosen) primary else Color.Transparent)
                                        .clickable { selected=date }.aspectRatio(.85f).padding(vertical=4.dp),
                                        horizontalAlignment=Alignment.CenterHorizontally, verticalArrangement=Arrangement.Center) {
                                        Text("${date.dayOfMonth}", color=if(chosen) Color.White else if(date.dayOfWeek.value==7) Color(0xFFD36B5B) else ink,
                                            fontSize=14.sp, fontWeight=if(isToday||chosen) FontWeight.Bold else FontWeight.Medium)
                                        Text(if(lunar.day==1) "${lunar.day}/${lunar.month}" else "${lunar.day}",
                                            color=if(chosen) Color.White.copy(alpha=.85f) else if(lunar.day==1) Gold else muted, fontSize=9.sp)
                                        if(isToday&&!chosen) Box(Modifier.padding(top=2.dp).size(4.dp).background(Gold,CircleShape))
                                    }
                                }
                            }
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
                val l = VietnameseLunar.toLunar(selected)
                val detail = DayFacts.forDate(selected, l)
                Card(shape=RoundedCornerShape(22.dp), colors=CardDefaults.cardColors(containerColor=card),
                    modifier=Modifier.weight(1f, fill=false)) {
                    Column(Modifier.fillMaxWidth().padding(16.dp)) {
                        Text("THÔNG TIN NGÀY", color=primary, fontSize=11.sp, fontWeight=FontWeight.Bold, letterSpacing=1.3.sp)
                        Row(verticalAlignment=Alignment.Bottom) {
                            Text("${selected.dayOfMonth}", color=ink, fontSize=43.sp, fontWeight=FontWeight.Bold)
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.padding(bottom=6.dp)) {
                                Text("${selected.monthValue}/${selected.year} · ${selected.dayOfWeek.toVietnamese()}", color=ink, fontWeight=FontWeight.SemiBold)
                                Text("Ngày âm: ${l.day}/${l.month}/${l.year}${if(l.leap) " (nhuận)" else ""}", color=Gold, fontWeight=FontWeight.Bold)
                            }
                        }
                        HorizontalDivider(color=muted.copy(alpha=.25f), modifier=Modifier.padding(vertical=8.dp))
                        InfoLine("Can chi ngày", detail.canChiDay)
                        InfoLine("Can chi năm", detail.canChiYear)
                        InfoLine("Tiết khí gần đúng", detail.solarTerm)
                        InfoLine("Ngày theo dân gian", detail.dayQuality)
                        InfoLine("Tuổi xung", detail.clash)
                        val holidays = detail.holidays
                        if(holidays.isNotEmpty()) {
                            Text("Dịp đặc biệt: ${holidays.joinToString(" · ")}", color=Gold, fontSize=12.sp,
                                fontWeight=FontWeight.SemiBold, modifier=Modifier.padding(top=7.dp))
                        }
                        Text("Giờ hoàng đạo (tham khảo): ${detail.goodHours}", color=muted, fontSize=11.sp,
                            modifier=Modifier.padding(top=7.dp))
                    }
                }
                Spacer(Modifier.height(9.dp))
                Card(shape=RoundedCornerShape(18.dp), colors=CardDefaults.cardColors(containerColor=card)) {
                    Column(Modifier.padding(horizontal=14.dp, vertical=9.dp)) {
                        Row(verticalAlignment=Alignment.CenterVertically) {
                            Text("Tùy chỉnh giao diện", color=ink, fontWeight=FontWeight.SemiBold, modifier=Modifier.weight(1f))
                            Text("Chế độ tối", color=muted, fontSize=12.sp)
                            Switch(checked=dark, onCheckedChange={dark=it})
                        }
                        Row(verticalAlignment=Alignment.CenterVertically) {
                            Text("Màu chủ đạo", color=muted, fontSize=12.sp, modifier=Modifier.weight(1f))
                            listOf(Green,Color(0xFF8A3D35),Color(0xFF315D91)).forEachIndexed { i,c ->
                                Box(Modifier.padding(start=9.dp).size(23.dp).clip(CircleShape).background(c)
                                    .clickable { accent=i })
                            }
                        }
                    }
                }
                Text("Lịch âm Việt Nam UTC+7 · Thông tin ngày tốt xấu chỉ mang tính tham khảo",
                    color=muted, fontSize=9.sp, textAlign=TextAlign.Center, modifier=Modifier.fillMaxWidth().padding(top=7.dp))
            }
        }
    }
}

@Composable
private fun InfoLine(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical=2.dp), verticalAlignment=Alignment.CenterVertically) {
        Text(label, color=Color.Gray, fontSize=11.sp, modifier=Modifier.weight(1f))
        Text(value, color=MaterialTheme.colorScheme.onSurface, fontSize=11.sp, fontWeight=FontWeight.SemiBold,
            textAlign=TextAlign.End)
    }
}

fun java.time.DayOfWeek.toVietnamese(): String = when(this) {
    java.time.DayOfWeek.MONDAY -> "Thứ Hai"
    java.time.DayOfWeek.TUESDAY -> "Thứ Ba"
    java.time.DayOfWeek.WEDNESDAY -> "Thứ Tư"
    java.time.DayOfWeek.THURSDAY -> "Thứ Năm"
    java.time.DayOfWeek.FRIDAY -> "Thứ Sáu"
    java.time.DayOfWeek.SATURDAY -> "Thứ Bảy"
    else -> "Chủ Nhật"
}

private data class DayFact(val canChiDay:String,val canChiYear:String,val solarTerm:String,
    val dayQuality:String,val clash:String,val goodHours:String,val holidays:List<String>)

private object DayFacts {
    private val stems=listOf("Giáp","Ất","Bính","Đinh","Mậu","Kỷ","Canh","Tân","Nhâm","Quý")
    private val branches=listOf("Tý","Sửu","Dần","Mão","Thìn","Tỵ","Ngọ","Mùi","Thân","Dậu","Tuất","Hợi")
    private val animals=listOf("Tý","Sửu","Dần","Mão","Thìn","Tỵ","Ngọ","Mùi","Thân","Dậu","Tuất","Hợi")
    private val terms=listOf("Xuân phân","Thanh minh","Cốc vũ","Lập hạ","Tiểu mãn","Mang chủng",
        "Hạ chí","Tiểu thử","Đại thử","Lập thu","Xử thử","Bạch lộ","Thu phân","Hàn lộ",
        "Sương giáng","Lập đông","Tiểu tuyết","Đại tuyết","Đông chí","Tiểu hàn","Đại hàn","Lập xuân","Vũ thủy","Kinh trập")
    fun forDate(d:LocalDate,l:LunarDate):DayFact {
        val jd=VietnameseLunar.julianDay(d)
        val dayIndex=(jd+9)%10
        val branch=(jd+1)%12
        val yearIndex=(l.year-1984+60)%60
        val yearName="${stems[yearIndex%10]} ${branches[yearIndex%12]}"
        val dayName="${stems[dayIndex.toInt()]} ${branches[branch.toInt()]}"
        val quality=listOf("Ngày bình hòa","Ngày cát (tham khảo)","Ngày bình hòa","Ngày cần thận trọng")[((jd%4)+4)%4]
        val clash=animals[(branch.toInt()+6)%12]
        val term=terms[VietnameseLunar.solarTermIndex(d)]
        val holidays=mutableListOf<String>()
        if(d.monthValue==1&&d.dayOfMonth==1) holidays.add("Tết Dương lịch")
        if(d.monthValue==4&&d.dayOfMonth==30) holidays.add("Ngày Giải phóng")
        if(d.monthValue==5&&d.dayOfMonth==1) holidays.add("Quốc tế Lao động")
        if(d.monthValue==9&&d.dayOfMonth==2) holidays.add("Quốc khánh")
        if(l.day==1&&l.month==1) holidays.add("Tết Nguyên đán")
        if(l.day==10&&l.month==3) holidays.add("Giỗ Tổ Hùng Vương")
        if(l.day==15&&l.month==1) holidays.add("Rằm tháng Giêng")
        if(l.day==15&&l.month==7) holidays.add("Vu Lan")
        if(l.day==15&&l.month==8) holidays.add("Tết Trung thu")
        if(l.day==1&&l.month==7) holidays.add("Mùng 1 tháng Bảy")
        val hours="Tý · Sửu · Mão · Ngọ · Thân · Dậu"
        return DayFact(dayName,yearName,term,quality,"$clash",hours,holidays)
    }
}

data class LunarDate(val day:Int,val month:Int,val year:Int,val leap:Boolean)

object VietnameseLunar {
    private const val PI=Math.PI
    fun julianDay(date:LocalDate):Int = jdFromDate(date.dayOfMonth,date.monthValue,date.year)
    private fun jdFromDate(d:Int,m:Int,y:Int):Int {
        val a=(14-m)/12; val yy=y+4800-a; val mm=m+12*a-3
        var jd=d+(153*mm+2)/5+365*yy+yy/4-yy/100+yy/400-32045
        if(jd<2299161) jd=d+(153*mm+2)/5+365*yy+yy/4-32083
        return jd
    }
    private fun newMoon(k:Int):Double {
        val t=k/1236.85; val t2=t*t; val t3=t2*t; val dr=PI/180
        var jd=2415020.75933+29.53058868*k+0.0001178*t2-0.000000155*t3
        jd+=0.00033*Math.sin((166.56+132.87*t-0.009173*t2)*dr)
        val m=359.2242+29.10535608*k-0.0000333*t2-0.00000347*t3
        val mp=306.0253+385.81691806*k+0.0107306*t2+0.00001236*t3
        val f=21.2964+390.67050646*k-0.0016528*t2-0.00000239*t3
        var c=(0.1734-0.000393*t)*Math.sin(m*dr)+0.0021*Math.sin(2*dr*m)
        c-=0.4068*Math.sin(mp*dr); c+=0.0161*Math.sin(dr*2*mp); c-=0.0004*Math.sin(dr*3*mp)
        c+=0.0104*Math.sin(dr*2*f)-0.0051*Math.sin(dr*(m+mp))
        c-=0.0074*Math.sin(dr*(m-mp))-0.0004*Math.sin(dr*(2*f+m))
        c-=0.0004*Math.sin(dr*(2*f-m))+0.0006*Math.sin(dr*(2*f+mp))
        c+=0.0010*Math.sin(dr*(2*f-mp))+0.0005*Math.sin(dr*(2*mp+m))
        val delta=if(t < -11) 0.001+0.000839*t+0.0002261*t2-0.00000845*t3-0.000000081*t*t3
            else -0.000278+0.000265*t+0.000262*t2
        return jd+c-delta
    }
    private fun newMoonDay(k:Int,tz:Double)=kotlin.math.floor(newMoon(k)+0.5+tz/24).toInt()
    private fun sunLongitude(day:Int,tz:Double):Int {
        val t=(day-0.5-tz/24-2451545.0)/36525; val t2=t*t; val dr=PI/180
        val m=357.52910+35999.05030*t-0.0001559*t2-0.00000048*t*t2
        val l0=280.46645+36000.76983*t+0.0003032*t2
        var dl=(1.914600-0.004817*t-0.000014*t2)*Math.sin(dr*m)
        dl+=(0.019993-0.000101*t)*Math.sin(2*dr*m)+0.000290*Math.sin(3*dr*m)
        var lon=(l0+dl)*dr; lon-=2*PI*kotlin.math.floor(lon/(2*PI))
        return kotlin.math.floor(lon/PI*6).toInt()
    }
    fun solarTermIndex(date:LocalDate):Int {
        val day=julianDay(date); val tz=7.0
        val t=(day-0.5-tz/24-2451545.0)/36525; val t2=t*t; val dr=PI/180
        val m=357.52910+35999.05030*t-0.0001559*t2-0.00000048*t*t2
        val l0=280.46645+36000.76983*t+0.0003032*t2
        var dl=(1.914600-0.004817*t-0.000014*t2)*Math.sin(dr*m)
        dl+=(0.019993-0.000101*t)*Math.sin(2*dr*m)+0.000290*Math.sin(3*dr*m)
        var lon=(l0+dl)*dr; lon-=2*PI*kotlin.math.floor(lon/(2*PI))
        return (kotlin.math.floor(lon/PI*12).toInt()).coerceIn(0,23)
    }
    private fun month11(y:Int,tz:Double):Int {
        val off=jdFromDate(31,12,y)-2415021; val k=kotlin.math.floor(off/29.530588853).toInt()
        var nm=newMoonDay(k,tz); if(sunLongitude(nm,tz)>=9) nm=newMoonDay(k-1,tz)
        return nm
    }
    private fun leapOffset(a11:Int,tz:Double):Int {
        val k=kotlin.math.floor(0.5+(a11-2415021.076998695)/29.530588853).toInt()
        var i=1; var last=-1; var arc=sunLongitude(newMoonDay(k+i,tz),tz)
        do { last=arc; i++; arc=sunLongitude(newMoonDay(k+i,tz),tz) } while(arc!=last&&i<14)
        return i-1
    }
    fun toLunar(date:LocalDate):LunarDate {
        val tz=7.0; val dn=julianDay(date)
        val k=kotlin.math.floor((dn-2415021.076998695)/29.530588853).toInt()
        var start=newMoonDay(k+1,tz); if(start>dn) start=newMoonDay(k,tz)
        var a11=month11(date.year,tz); var b11=a11; val year:Int
        if(a11>=start) { year=date.year; a11=month11(date.year-1,tz) }
        else { year=date.year+1; b11=month11(date.year+1,tz) }
        val lunarDay=dn-start+1; val diff=kotlin.math.floor((start-a11)/29.0).toInt()
        var leap=false; var lunarMonth=diff+11
        if(b11-a11>365) {
            val leapDiff=leapOffset(a11,tz)
            if(diff>=leapDiff) { lunarMonth=diff+10; if(diff==leapDiff) leap=true }
        }
        if(lunarMonth>12) lunarMonth-=12
        var lunarYear=year
        if(lunarMonth>=11&&diff<4) lunarYear--
        return LunarDate(lunarDay,lunarMonth,lunarYear,leap)
    }
}
