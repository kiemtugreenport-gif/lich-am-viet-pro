# Lịch Âm Việt Pro — Android

Bộ mã nguồn Android Kotlin + Jetpack Compose, có thể build APK bằng GitHub Actions.

## Tính năng
- Lịch tháng âm/dương, chọn ngày, chuyển tháng, về hôm nay.
- Thông tin ngày: ngày âm, tháng nhuận, can chi ngày/năm, tuổi xung.
- Tiết khí hiển thị theo ước lượng ngày trong năm.
- Các dịp lễ dương lịch và ngày lễ âm lịch phổ biến: Tết, rằm tháng Giêng, Giỗ Tổ, Vu Lan, Trung thu.
- Thông tin ngày tốt/xấu và giờ hoàng đạo ở mức tham khảo dân gian, không phải lịch vạn niên đã thẩm định.
- Chế độ sáng/tối và ba màu chủ đạo.
- Widget màn hình chính Android: ngày dương, ngày âm và giờ hiện tại.

## Build APK qua GitHub
1. Giải nén ZIP.
2. Tạo repository mới trên https://github.com.
3. Upload toàn bộ nội dung đã giải nén, bao gồm thư mục ẩn `.github`.
4. Commit lên nhánh `main`.
5. Vào tab **Actions**, chọn workflow **Build Android APK**.
6. Chờ workflow hoàn tất, mở lần chạy mới nhất và tải Artifact `LichAmVietPro-debug-apk`.
7. Giải nén artifact, lấy `app-debug.apk` để cài trên điện thoại Android.

## Widget
Sau khi cài app, nhấn giữ màn hình chính Android → Widget → Lịch Âm Việt Pro → kéo widget ra màn hình. Một số launcher có thể cập nhật widget theo lịch riêng.

## Yêu cầu
- Android 7.0 trở lên.
- JDK 17 và Gradle 8.9 nếu build thủ công.
- Build thủ công: `gradle assembleDebug`.

## Lưu ý về dữ liệu
Bản này chạy ngoại tuyến, không cần quyền vị trí hay Internet. Can chi, tiết khí, giờ hoàng đạo và đánh giá tốt/xấu đang ở mức thông tin tham khảo; cần kiểm thử/đối chiếu với lịch vạn niên đáng tin cậy trước khi dùng cho nghi lễ hoặc quyết định quan trọng. APK tạo từ workflow là bản debug, chưa ký phát hành Play Store.
