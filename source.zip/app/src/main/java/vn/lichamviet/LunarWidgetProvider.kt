package vn.lichamviet

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import java.time.LocalDate

class LunarWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        val now = LocalDate.now()
        val lunar = VietnameseLunar.toLunar(now)
        val facts = DayFacts.forDate(now, lunar)
        val open = PendingIntent.getActivity(
            context, 0, Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val views = RemoteViews(context.packageName, R.layout.lunar_widget)
        views.setTextViewText(R.id.widget_weekday, now.dayOfWeek.toVietnamese().uppercase())
        views.setTextViewText(R.id.widget_solar, "${now.dayOfMonth}/${now.monthValue}/${now.year}")
        views.setTextViewText(R.id.widget_canchi, "Năm ${facts.canChiYear}")
        views.setTextViewText(R.id.widget_lunar, "${lunar.day}/${lunar.month}")
        views.setTextViewText(
            R.id.widget_lunar_label,
            if (lunar.leap) "Âm lịch (nhuận)" else "Âm lịch"
        )
        views.setOnClickPendingIntent(R.id.widget_root, open)
        ids.forEach { manager.updateAppWidget(it, views) }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        when (intent.action) {
            Intent.ACTION_DATE_CHANGED, Intent.ACTION_TIME_CHANGED, Intent.ACTION_TIMEZONE_CHANGED -> {
                val manager = AppWidgetManager.getInstance(context)
                val ids = manager.getAppWidgetIds(ComponentName(context, LunarWidgetProvider::class.java))
                onUpdate(context, manager, ids)
            }
        }
    }
}
