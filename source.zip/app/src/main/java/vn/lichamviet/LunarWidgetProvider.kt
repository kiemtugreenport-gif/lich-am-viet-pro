package vn.lichamviet

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.widget.RemoteViews
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter

class LunarWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        val now = LocalDate.now()
        val lunar = VietnameseLunar.toLunar(now)
        val time = LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm"))
        val views = RemoteViews(context.packageName, R.layout.lunar_widget)
        views.setTextViewText(R.id.widget_weekday, now.dayOfWeek.toVietnamese().uppercase())
        views.setTextViewText(R.id.widget_solar, "${now.dayOfMonth}/${now.monthValue}/${now.year}")
        views.setTextViewText(R.id.widget_lunar, "Âm lịch: ${lunar.day}/${lunar.month}/${lunar.year}")
        views.setTextViewText(R.id.widget_clock, "Giờ hiện tại: $time")
        ids.forEach { manager.updateAppWidget(it, views) }
    }
}
